export interface ILivro {
    nome: string
    descricao: string
    autor: string
    imagem: string
    preco: number
}